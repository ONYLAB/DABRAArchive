##################################
# Based on App:                  # 
# Biodiversity in National Parks #
# by Alessio Benedetti           #  
# Modified by Osman Y, CBER, 2023#
# ui.R file                      #
##################################

library(shinydashboard)
library(shinycssloaders)
library(DT)
library(plotly)
library(markdown)

###########
# LOAD UI #
###########

shinyUI(fluidPage(
  
  # load custom stylesheet
  includeCSS("www/style.css"),
  
  # remove shiny "red" warning messages on GUI
  tags$style(type="text/css",
             ".shiny-output-error { visibility: hidden; }",
             ".shiny-output-error:before { visibility: hidden; }"
  ),
  
  # load page layout
  dashboardPage(
    
    skin = "green",
    
    dashboardHeader(title="DABRA Archive", titleWidth = 300),
    
    dashboardSidebar(width = 300,
                     sidebarMenu(
                       HTML(paste0(
                         "<br>",
                         "<a href='https://www.fda.gov/about-fda/center-biologics-evaluation-and-research-cber/cber-offices-divisions' target='_blank'><img style = 'display: block; margin-left: auto; margin-right: auto;' src='WC_DABRA.svg' width = '286'></a>",
                         "<br>",
                         "<p style = 'text-align: center;'><small><a href='https://www.fda.gov/about-fda/center-biologics-evaluation-and-research-cber/cber-offices-divisions' target='_blank'>FDA/CBER/OBPV <br>Division of <br>Analytics and Benefit-Risk Assessment</a></small></p>",
                         "<br>"
                       )),
                       menuItem("Home", tabName = "home", icon = icon("house")),
                       menuItem("COVID Charts", tabName = "charts", icon = icon("virus", lib = "font-awesome")),
                       menuItem("Medicare Charts", tabName = "Medicarecharts", icon = icon("fa-solid fa-person-cane", lib = "font-awesome")),
                       menuItem("Review Guidance", tabName = "Guidance", icon = icon("fa-sharp fa-regular fa-compass", lib = "font-awesome")),
                       menuItem("DABRA Science in Numbers", tabName = "DScience", icon = icon("flask", lib = "font-awesome")),
                       menuItem("FDA Acronym Finder", tabName = "Facronym", icon = icon("fa-solid fa-magnifying-glass", lib = "font-awesome")),
                       menuItem("Releases", tabName = "releases", icon = icon("bars-progress")),
                       HTML(paste0(
                         "<br><br><br><br><br><br><br><br><br>",
                         "<table style='margin-left:auto; margin-right:auto;'>",
                         "<tr>",
                         "<td style='padding: 5px;'><a href='https://www.facebook.com/FDA' target='_blank'><i class='fab fa-facebook-square fa-lg'></i></a></td>",
                         "<td style='padding: 5px;'><a href='https://youtube.com/@US_FDA' target='_blank'><i class='fab fa-youtube fa-lg'></i></a></td>",
                         "<td style='padding: 5px;'><a href='https://www.twitter.com/US_FDA' target='_blank'><i class='fab fa-twitter fa-lg'></i></a></td>",
                         "<td style='padding: 5px;'><a href='https://instagram.com/FDA' target='_blank'><i class='fab fa-instagram fa-lg'></i></a></td>",
                         "<td style='padding: 5px;'><a href='https://www.flickr.com/photos/fdaphotos/' target='_blank'><i class='fab fa-flickr fa-lg'></i></a></td>",
                         "</tr>",
                         "</table>",
                         "<br>"),
                         HTML(paste0(
                           "<script>",
                           "var today = new Date();",
                           "var yyyy = today.getFullYear();",
                           "</script>",
                           "<p style = 'text-align: center;'><small>&copy; - <a href='https://alessiobenedetti.com' target='_blank'>alessiobenedetti.com</a> - <script>document.write(yyyy);</script><br>Modified by Osman</small></p>")
                         ))
                     )
                     
    ), # end dashboardSidebar
    
    dashboardBody(
      
      tabItems(
        
        tabItem(tabName = "home",
                
                # home section
                includeMarkdown("www/home.md")
                
        ),
        
        tabItem(tabName = "charts",
                
                # ggplot2 species charts section
                includeMarkdown("www/COVIDcharts.md"),
                fluidRow(column(12, uiOutput("categorySelectComboChart"))),
                fluidRow(column(12,htmlOutput("inc"))),
                fluidRow(column(12,htmlOutput("nar")))
        ),
        
        
        tabItem(tabName = "Medicarecharts",
                
                # ggplot2 species charts section
                includeMarkdown("www/Medicarecharts.md"),
                fluidRow(column(12, uiOutput("categorySelectComboMedicareChart"))),
                fluidRow(column(12,htmlOutput("Medicareinc"))),
                fluidRow(column(12,htmlOutput("Medicarenar")))
        ),         
        
        tabItem(tabName = "Guidance",
                # home section
                includeMarkdown("www/Guidance.md")
        ),
        
        # tabItem(tabName = "BRGuidance",
        #   # home section
        #   includeMarkdown("www/BRGuidance.md")
        # ),                
        
        tabItem(tabName = "DScience",
                # home section
                #includeMarkdown("www/DScience.md")
                fluidRow(column(4,includeMarkdown("www/SciOutputDABRA.md")),column(8,htmlOutput("sch")))
                #includeHTML("https://scholar.google.com/citations?hl=en&user=VTaDTXwAAAAJ&sortby=pubdate&view_op=list_works")
        ),
        
        tabItem(tabName = "Facronym",
                includeMarkdown("www/Facronym.md"),
                fluidRow(column(12,textInput("search_dict", "Enter a word to search for:", "PDUFA"))),
                fluidRow(column(12,verbatimTextOutput("definition")))
        ),
        
        tabItem(tabName = "releases", includeMarkdown("www/releases.md"))
        
      )
      
    ) # end dashboardBody
    
  )# end dashboardPage
  
))
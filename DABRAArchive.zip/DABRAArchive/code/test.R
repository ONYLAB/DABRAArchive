library(shiny)

# Load the dictionary data
data <- read.csv("dictionary.csv")

# Define the UI for the app
ui <- fluidPage(
  titlePanel("Simple English Language Dictionary"),
  sidebarLayout(
    sidebarPanel(
      textInput("search", "Enter a word to search for:")
    ),
    mainPanel(
      verbatimTextOutput("definition")
    )
  )
)

# Define the server logic
server <- function(input, output) {
  # Define the reactive expression that filters the dictionary data based on the user's search query
  filtered_data <- reactive({
    data[grep(input$search, data$word), ]
  })
  
  # Define the output to display the definition of the selected word
  output$definition <- renderText({
    if (nrow(filtered_data()) == 0) {
      "No matching words found."
    } else {
      paste(filtered_data()$word, ": ", filtered_data()$definition, sep = "")
    }
  })
}

# Run the app
shinyApp(ui, server)

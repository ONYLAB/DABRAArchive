##################################
# Based on App:                  # 
# Biodiversity in National Parks #
# by Alessio Benedetti           #  
# Modified by Osman Y, CBER, 2023#
# server.R file                  #
##################################

library(shiny)
library(tidyverse)
library(rvest)
library(plotly)
library(markdown)

#####################
# SUPPORT FUNCTIONS #
#####################

##################
# DATA WRANGLING #
##################

tabCOVID <- read_csv("www/tabCOVID.csv", 
                     col_types = cols(ID = col_character(), 
                                      Title = col_character()))

COVIDCategories <- sort(unique(tabCOVID$Title))



tabMedicare <- read_csv("www/tabMedicare.csv", 
                        col_types = cols(ID = col_character(), 
                                         Title = col_character()))

MedicareCategories <- sort(unique(tabMedicare$Title))

# # Load the dictionary data
dictionary <- read.csv("www/dictionary.csv")

################
# SERVER LOGIC #
################

setwd(getSrcDirectory(function(){})[1])

shinyServer(function(input, output) {
   
   myhtmlfilepath <- getwd() # change to your path
   addResourcePath('myhtmlfiles', myhtmlfilepath)  
   
   #######################
   ###### COVID-19 charts
   output$categorySelectComboChart <- renderUI({
      selectizeInput("selectedCategoryChart","Select a chart:", COVIDCategories, width='100%')
   })
   
   getPage <- function() {
      return(tags$iframe(src = paste0("myhtmlfiles/www/", tabCOVID[tabCOVID$Title==input$selectedCategoryChart,]$ID, "plot.html"), frameborder="no;", style="background: #FFFFFF;height: 50vh;", width = "100%", scrolling = "yes"))
   }
   
   output$inc <- renderUI({
      req(input$selectedCategoryChart)
      getPage()
   })
   
   getMD <- function() {
      return(includeMarkdown(paste0(myhtmlfilepath,"/www/",tabCOVID[tabCOVID$Title==input$selectedCategoryChart,]$ID,"mark.md")))
   }
   
   output$nar <- renderUI({
      req(input$selectedCategoryChart)
      getMD()
   })
   
   #######################
   ###### Medicare charts
   output$categorySelectComboMedicareChart <- renderUI({
      selectizeInput("selectedCategoryMedicareChart","Select a chart:", MedicareCategories, width='100%')
   })
   
   getMedicarePage <- function() {
      return(tags$iframe(src = paste0("myhtmlfiles/www/", tabMedicare[tabMedicare$Title==input$selectedCategoryMedicareChart,]$ID, "plot.html"), frameborder="no;", style="background: #FFFFFF;height: 50vh;", width = "100%", scrolling = "yes"))
   }
   
   output$Medicareinc <- renderUI({
      req(input$selectedCategoryMedicareChart)
      getMedicarePage()
   })
   
   getMedicareMD <- function() {
      return(includeMarkdown(paste0(myhtmlfilepath,"/www/",tabMedicare[tabMedicare$Title==input$selectedCategoryMedicareChart,]$ID,"mark.md")))
   }
   
   output$Medicarenar <- renderUI({
      req(input$selectedCategoryMedicareChart)
      getMedicareMD()
   })
   
   #######################
   #### DABRA IN NUMBERS
   getScholarPage <- function() {
      return(tags$iframe(src = paste0("myhtmlfiles/www/DABRAOBPV_coauthor_network.html"), frameborder="no;", style="background: #FFFFFF;height: 90vh;", width = "100%", scrolling = "no"))
   }#"https://scholar.google.com/citations?hl=en&user=VTaDTXwAAAAJ&view_op=list_works&sortby=pubdate"
   
   output$sch <- renderUI({
      getScholarPage()
   })
   
   #######################
   #### FDA Acronym Finder
   
   # Define the reactive expression that filters the dictionary data based on the user's search query
   filtered_data <- reactive({
      dictionary[grep(input$search_dict, dictionary$word, fixed=TRUE), ]
   })
   
   # Define the output to display the definition of the selected word
   output$definition <- renderText({
      if (nrow(filtered_data()) == 0) {
         "No matching words found."
      } else if  (input$search_dict == ''){
         "No matching words found."         
      } else {
         paste0(filtered_data()$word, ": ", filtered_data()$definition, "\n", sep = "\n")
      }
   })
   
})
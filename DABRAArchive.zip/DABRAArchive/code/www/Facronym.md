## FDA Acronym Finder (version April 2023)
This finder was made possible thanks to prior efforts from FDA OC Immediate Office.
<br>
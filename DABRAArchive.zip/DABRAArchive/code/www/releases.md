### Releases
<br>
<p style=" font-size:14px; text-align:justify;">
April 10, 2023&nbsp;&nbsp;
<b>version:</b> 0.41
<ul style="padding-left:5em">
  <li type="square">Youtube User Introduction video</li>
  <li type="square">Addition of FDA Acronym Finder tab</li>
</ul></p2>
</p>
<b>version:</b> 0.4
<ul style="padding-left:5em">
  <li type="square">Addition of plots from Menis et al. 2021, Open Forum Infectious Diseases</li>
  <li type="square">Starting new tab Medicare Charts</li>
</ul></p2>
</p>
March 16, 2023&nbsp;&nbsp;
<b>version:</b> 0.3
<ul style="padding-left:5em">
 <li type="square">Addition of DABRA Coauthor Network and DABRA Science</li>
 <li type="square">Merger of RWE and B-R Guidance Links</li>
</ul></p2>
</p>
March 6, 2023&nbsp;&nbsp;
<b>version:</b> 0.2
<ul style="padding-left:5em">
 <li type="square">Addition of RWE and B-R Guidance Links</li>
 <li type="square">Addition of color-blind friendly palette</li>
</ul></p2>
</p>
March 1, 2023&nbsp;&nbsp;
<b>version:</b> 0.1
<ul style="padding-left:5em">
 <li type="square">Addition of plots from Lu et al. 2021, The Journal of Infectious Diseases</li>
</ul></p2>
</p>
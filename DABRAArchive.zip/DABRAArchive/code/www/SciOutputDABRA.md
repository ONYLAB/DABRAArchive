# DABRA Scientific Output
More than 100 scientific **[publications](https://scholar.google.com/citations?hl=en&user=VTaDTXwAAAAJ&view_op=list_works&sortby=pubdate)** since 2008. 

1. Transfusion, 16 articles 
2. Vaccine, 10 articles 
3. Journal of Infectious Diseases, 6 articles 
4. Pharmacoepidemiology and Drug Safety, 4 articles
5. Clinical Infectious Diseases, 4 articles
6. PLoS One, 3 articles 
7. Vox Sanguinis, 2 articles 
8. AAPS Journal, 2 articles
9. Regulatory Toxicology and Pharmacology, 2 articles 
10. Open Forum Infectious Diseases, 2 articles

## Top 5 Most-cited Articles

 1. Kreimeyer, Kory, et al. "[Natural language processing systems for capturing and standardizing unstructured clinical information: a systematic review.](https://www.sciencedirect.com/science/article/pii/S1532046417301685)" Journal of biomedical informatics 73 (2017): 14-29.
 2. Salmon, Daniel A., et al. "[Association between Guillain-Barré syndrome and influenza A (H1N1) 2009 monovalent inactivated vaccines in the USA: a meta-analysis.](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736%2812%29621898/fulltext)" The Lancet 381.9876 (2013): 1461-1468.
 3. Izurieta, Hector S., et al. "[Comparative effectiveness of high-dose versus standard-dose influenza vaccines in US residents aged 65 years and older from 2012 to 2013 using Medicare data: a retrospective cohort analysis.](https://www.sciencedirect.com/science/article/pii/S1473309914710874)" The Lancet Infectious diseases 15.3 (2015): 293-300.
 4. Mitkus, Robert J., et al. "[Updated aluminum pharmacokinetics following infant exposures through diet and vaccination.](https://www.sciencedirect.com/science/article/pii/S0264410X11015799)" Vaccine 29.51 (2011): 9538-9543.
 5. Izurieta, Hector S., et al. "[Relative effectiveness of cell-cultured and egg-based influenza vaccines among elderly persons in the United States, 2017–2018.](https://academic.oup.com/jid/article/220/8/1255/5250955)" The Journal of infectious diseases 220.8 (2019): 1255-1264.
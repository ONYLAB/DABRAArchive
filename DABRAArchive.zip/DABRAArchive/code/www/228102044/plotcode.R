library(data.table)
library(plotly)

# Set the font family and size for the plot
font <- list(family = "Arial", size = 16, color = "#333")

# Set the title font
title_font <- list(family = "Georgia", size = 24, color = "#555")

# Set the legend font
legend_font <- list(family = "Calibri", size = 16, color = "#777")

# Create the data frame
df <- data.frame(
  row.names = c("ICU/CCU admission", "Ventilator use/ECMO", "Inpatient renal replacement therapy", "Inpatient death"),
  "Elderly NH Population" = c(23.7, 10.7, 5.7, 24.7),
  "ESRD Population" = c(25.4, 14.6, 71.8, 17.5),
  "Community-Dwelling Elderly" = c(21.0, 10.6, 2.4, 15.3)
)

m <- list(
  l = 10,
  r = 10,
  b = 10,
  t = 50,
  pad = 4
)

# Create the barplot
plot_ly(df, x = row.names(df), y = ~df[,1], type = 'bar', name = gsub('\\.', ' ', colnames(df)[1]), marker = list(color = '#FFA07A')) %>%
  add_trace(y = ~df[,2], name = gsub('\\.', ' ', colnames(df)[2]), marker = list(color = '#AEC6CF')) %>%
  add_trace(y = ~df[,3], name = gsub('\\.', ' ', colnames(df)[3]), marker = list(color = '#C2D985')) %>%
  layout(title = list(text = "<b><i>Hospitalization-related outcomes</i></b>", font = title_font),
         yaxis = list(title = "<b>%</b>", titlefont = font),
         xaxis = list(tickfont = font),
         legend = list(x=0.2,y=.8,traceorder="normal",font = legend_font),
         margin = m,
         barmode = 'group')

# Load necessary libraries
library(plotly)
library(dplyr)
library(RColorBrewer)

# Set the font family and size for the plot
font <- list(family = "Arial", size = 16, color = "#333")

# Set the title font
title_font <- list(family = "Georgia", size = 24, color = "#555")

# Set the legend font
legend_font <- list(family = "Calibri", size = 16, color = "#777")

# Create a sample dataset
df <- data.frame(
  year = rep(2006:2017, 3),
  variable = rep(c("Overall", "Females", "Males"), each = 12),
  value = c(4,3,5,6,5,5,5,7,7,10,9,9,3,3,4,6,5,5,4,6,6,9,8,8,4,4,5,6,6,6,5,8,8,10,10,10)
)

# Choose a color palette that is color-blind friendly
colors <- brewer.pal(3, "Dark2")

# Create a plotly plot
plot <- df %>% 
  plot_ly(x = ~year, y = ~value, color = ~variable, type = "scatter", mode = "lines") %>% 
  layout(title = "Annual Babesiosis Rates Among Elderly (65+ YOA) Medicare Beneficiaries",
         xaxis = list(title = "Year"),
         yaxis = list(title = "Rate per 100,000 Babesiosis Beneficiery-Years"))

# Display the plot
plot

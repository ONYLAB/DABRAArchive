library(data.table)
library(plotly)

# Set the font family and size for the plot
font <- list(family = "Arial", size = 16, color = "#333")

# Set the title font
title_font <- list(family = "Georgia", size = 24, color = "#555")

# Set the legend font
legend_font <- list(family = "Calibri", size = 16, color = "#777")

# Create the data frame
df <- data.frame(
  row.names = c("COVID-19–related deaths", "COVID-19–related deaths without hospitalization", "COVID-19 hospitalizations", "COVID-19–related deaths or hospitalizations"),
  "Elderly NH Population" = c(943.7, 442.1, 1039.1, 1481.2),
  "ESRD Population" = c(259.4, 20.7, 874.5, 895.1),
  "Community-Dwelling Elderly" = c(33.9, 5.2, 118.0, 123.2)
)

m <- list(
  l = 10,
  r = 10,
  b = 10,
  t = 50,
  pad = 4
)

# Create the barplot
plot_ly(df, x = row.names(df), y = ~df[,1], type = 'bar', name = gsub('\\.', ' ', colnames(df)[1]), marker = list(color = '#FFA07A')) %>%
  add_trace(y = ~df[,2], name = gsub('\\.', ' ', colnames(df)[2]), marker = list(color = '#AEC6CF')) %>%
  add_trace(y = ~df[,3], name = gsub('\\.', ' ', colnames(df)[3]), marker = list(color = '#C2D985')) %>%
  layout(title = list(text = "<b><i>Severe COVID-19 outcomes</i></b>", font = title_font),
         yaxis = list(title = "<b>Rate per 10,000</b>", titlefont = font),
         xaxis = list(tickfont = font),
         legend = list(x=0.2,y=.8,traceorder="normal",font = legend_font),
         margin = m,
         barmode = 'group')

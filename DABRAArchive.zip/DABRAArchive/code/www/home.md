## Welcome !
<br><br>
<i> DABRA Archive</i> is an app that lets you visualize the past scientific findings of DABRA members, OBPV, CBER, FDA. The Archive also has links to relevant review guidance documents.

From the left navigation panel you will be able to access various charts concerning our efforts and other relevant documents.

It has been made with [shiny](https://shiny.rstudio.com/) and you may find the code on [github](https://github.com/ONYLAB/bioNPS/). The code was based on Alessio Benedetti's work for Biodiversity in National Parks which you may find at [github](https://github.com/abenedetti/bioNPS/) and [rcloud](https://rstudio.cloud/project/246130). 

For a quick walkthrough have a look at the video below.
<br><br><br>
<iframe style = "display: block; margin: auto;" width="640" height="360" src="https://www.youtube.com/embed/rFNm4mroWq8?hd=1"></iframe>
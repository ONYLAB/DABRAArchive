<<insertHTML:[test.html]

etc, etc, etc


htmltools::includeHTML("https://scholar.google.com/citations?hl=en&user=VTaDTXwAAAAJ&view_op=list_works&sortby=pubdate")


etc, etc, etc